from .index import Rtree

from .core import rt

__version__ = '0.8.3'
